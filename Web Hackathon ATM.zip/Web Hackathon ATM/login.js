
//const balance = 0;
var attempt = 3; // Variable to count number of attempts.
// Below function Executes on click of login button.
function validate(){
var username = document.getElementById("username").value;
var password = document.getElementById("password").value;
if ( username == "plpAdmin" && password == ""){
alert ("Login successfully");

displayBalance();
document.getElementById("content-container").style.display = "flex";
document.getElementById("login").style.display = "none";
document.getElementById("exit").style.visibility = "visible";
document.getElementById("user-name").innerHTML = username;
// document.getElementById("userBalance").innerHTML = "Ksh "+ balance; 

return false;
}
else{
attempt --;// Decrementing by one.
alert("You have left "+attempt+" attempt;");
// Disabling fields after 3 attempts.
if( attempt == 0){
document.getElementById("username").disabled = true;
document.getElementById("password").disabled = true;
document.getElementById("submit").disabled = true;
return false;
}
}
}
function exit(){
alert ("Are ypu Sure You want to exit?");
document.getElementById("content-container").style.display = "none";
document.getElementById("login").style.display = "block";
document.getElementById("exit").style.visibility = "hidden";
var username = document.getElementById("username").value='';
var password = document.getElementById("password").value='';
}
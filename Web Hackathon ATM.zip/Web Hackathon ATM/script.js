var user = {
            'Balance':0,
        };
 var transactions = [{

 }];

let userDetail =localStorage.getItem("user");
console.log(JSON.parse(userDetail));

let userTrans = localStorage.getItem("transactions");
console.log(JSON.parse(userTrans));



function getCash(){
	document.getElementById("get_cash").style.display = "flex";
	return false;
}
function putCash(){
	document.getElementById("put_cash").style.display = "flex";
	return false;
}

function closeApp(){
alert ("Are you Sure You want to exit?");
document.getElementById("get_cash").style.display = "none";
document.getElementById("put_cash").style.display = "none";
	return false;
}


// var userBalance = 2

function displayBalance(){
document.getElementById("userBalance").innerHTML = user.Balance;
}

function add_balance() {
	var time_now =document.getElementById("timer").innerHTML;
	const transact = document.querySelector("addAmount");
	const list = document.querySelector("ul");
	const inBal = document.getElementById("addAmount").value;
	const newBalance = parseInt(user.Balance) + parseInt(inBal);
	user.Balance = parseInt(newBalance);
	if (inBal==="") {
		alert("Enter a valid amount");
	} else if(inBal !=="") {
	confirm("Deposit Ksh "+inBal+" Into your Account");
	transactions.push(inBal);
	localStorage.setItem("user", JSON.stringify(user));
	document.getElementById("userBalance").innerHTML = user.Balance;
	console.log(newBalance);
	let userDetail =localStorage.getItem("user");
	localStorage.setItem("transactions", JSON.stringify("transactions"));
      // create list item, add innerHTML and append to ul
      const li = document.createElement("li");
      li.innerHTML = `You Deposited ${inBal} on ${curTime}</li>`;
      list.insertBefore(li, list.children[0]);
  }
  else{
  	return;
  }
}
function withdraw() {
	const transact = document.querySelector("addAmount");
	const list = document.querySelector("ul");
	const inBal = document.getElementById("getAmount").value;
	const newBalance = parseInt(user.Balance) - parseInt(inBal);
	user.Balance = parseInt(newBalance);
	if (inBal==="") {
		alert("Enter a valid amount");
	} else if(inBal !=="") {
	confirm("Withdraw Ksh"+inBal+" from your Account")
	localStorage.setItem("user", JSON.stringify(user));
	document.getElementById("userBalance").innerHTML = user.Balance;
	console.log(newBalance);
	let userDetail =localStorage.getItem("user");
	document.getElementById("userBalance").innerHTML = user.Balance;
	console.log(newBalance);
	localStorage.setItem("transactions", JSON.stringify("transactions"));
  // create list item, add innerHTML and append to ul
  	const li = document.createElement("li");
  	li.innerHTML = `<p>You Withdrew ${inBal} on ${curTime}</p>`;
  	list.insertBefore(li, list.children[0]);
  } else {
  	return;
  }
}


function addTransaction(){ 
}




//var time_now =document.getElementById("timer").value;
var today_now = new Date();
  var date = today_now.getFullYear()+'-'+(today_now.getMonth()+1)+'-'+today_now.getDate();
  const today = new Date();
  let h = today.getHours();
  let m = today.getMinutes();
  let s = today.getSeconds();
  m = checkTime(m);
  s = checkTime(s);
  var curTime = h + ":" + m + ":" + s+" "+date; 
function startTime() {
	var today_now = new Date();
  var date = today_now.getFullYear()+'-'+(today_now.getMonth()+1)+'-'+today_now.getDate();
  const today = new Date();
  let h = today.getHours();
  let m = today.getMinutes();
  let s = today.getSeconds();
  m = checkTime(m);
  s = checkTime(s);
  var curTime = h + ":" + m + ":" + s+" "+date; 
  document.getElementById('timer').innerHTML = curTime ;
  setTimeout(startTime, 1000);
}

function checkTime(i) {
  if (i < 10) {i = "0" + i};  // add zero in front of numbers < 10
  return i;
}